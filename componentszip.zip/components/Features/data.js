const reviews = [
    {
      id: 1,
      name: 'calorie calculator',
      job: 'web developer',
      image:
        'https://media.istockphoto.com/vectors/calorie-calculator-icon-vector-id1143579966?k=6&m=1143579966&s=612x612&w=0&h=s4atfhcvOTldyQ-8vjJTi3Tnzzd2VGnre4nZ2B8KAfE=',
      text:
        "I'm baby meggings twee health goth +1. Bicycle rights tumeric chartreuse before they sold out chambray pop-up. Shaman humblebrag pickled coloring book salvia hoodie, cold-pressed four dollar toast everyday carry",
    },
    {
      id: 2,
      name: 'anna johnson',
      job: 'web designer',
      image:
        'https://th.bing.com/th/id/OIP.VS47UsrUF1FXqHSBZ1LqwQHaHa?w=187&h=187&c=7&r=0&o=5&dpr=1.3&pid=1.7',
      text:
        'Helvetica artisan kinfolk thundercats lumbersexual blue bottle. Disrupt glossier gastropub deep v vice franzen hell of brooklyn twee enamel pin fashion axe.photo booth jean shorts artisan narwhal.',
    },
    {
      id: 3,
      name: 'peter jones',
      job: 'intern',
      image:
        'https://th.bing.com/th?id=OIP.8i0UrqLoLSozWTbHqS-MqQHaHZ&w=250&h=249&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2',
      text:
        'Sriracha literally flexitarian irony, vape marfa unicorn. Glossier tattooed 8-bit, fixie waistcoat offal activated charcoal slow-carb marfa hell of pabst raclette post-ironic jianbing swag.',
    },
    {
      id: 4,
      name: 'bill anderson',
      job: 'the boss',
      image:
        'https://th.bing.com/th/id/OIP.Km_203y7bvtZjTDq68wHoAHaE_?w=300&h=202&c=7&r=0&o=5&dpr=1.3&pid=1.7',
      text:
        'Edison bulb put a bird on it humblebrag, marfa pok pok heirloom fashion axe cray stumptown venmo actually seitan. VHS farm-to-table schlitz, edison bulb pop-up 3 wolf moon tote bag street art shabby chic. ',
    },
  ];
  
  export default reviews;
  